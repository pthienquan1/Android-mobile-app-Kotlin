package com.tuhoc.bai85_listviewnangcao_final

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ListView

class MainActivity : AppCompatActivity() {
    lateinit var customAdapter: CustomAdapter
    /* lateinit là khởi tạo muộn.
    * thông thường khai báo biến kotlin sẽ yêu cầu khởi tạo ( gán giá trị cho biến)
    * Ta có thể dùng lateinit để gán giá trị sau */
//ví dụ lateinit var chuoi:String
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //khai báo danh sách các item list
        var list = mutableListOf<OurData>()
        list.add(OurData(R.drawable.giatocrong,"Gia Tộc Rồng 2022","Gia Tộc Rồng xoay quanh vấn đề về cuộc nội chiến, tranh giành quyền lực giữa 2 phe \"Black\" của Rhaenyra Targaryen và phe \"Green\" của Alicent Hightower."))
        list.add(OurData(R.drawable.hoanhon,"Hoàn Hồn 2022","phim giả tưởng"))
        list.add(OurData(R.drawable.thanlan,"Thần Lan Vô Song","phim kiếm hiệp"))
        list.add(OurData(R.drawable.banghoa,"Băng Hỏa Ma Trù 2021","Băng Hỏa Ma Trù"))
        list.add(OurData(R.drawable.hoanhon,"Hoàn Hồn 2022","phim giả tưởng"))
        list.add(OurData(R.drawable.thanlan,"Thần Lan Vô Song","phim kiếm hiệp"))
        list.add(OurData(R.drawable.banghoa,"Băng Hỏa Ma Trù 2021","Băng Hỏa Ma Trù"))
        list.add(OurData(R.drawable.hoanhon,"Hoàn Hồn 2022","phim giả tưởng"))
        list.add(OurData(R.drawable.thanlan,"Thần Lan Vô Song","phim kiếm hiệp"))
        list.add(OurData(R.drawable.banghoa,"Băng Hỏa Ma Trù 2021","Băng Hỏa Ma Trù"))

        customAdapter = CustomAdapter(this,list)
        //khai báo biến list view Phim link tới view lvPhim
        val lvPhim = findViewById<ListView>(R.id.lvPhim)
        lvPhim.adapter = customAdapter
    }
}