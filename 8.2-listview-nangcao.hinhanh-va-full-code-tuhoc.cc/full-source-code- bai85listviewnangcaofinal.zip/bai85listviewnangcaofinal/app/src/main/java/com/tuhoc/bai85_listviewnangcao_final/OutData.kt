package com.tuhoc.bai85_listviewnangcao_final

class OurData (
    val image:Int,
    val title: String,
    val desc:String){
}
